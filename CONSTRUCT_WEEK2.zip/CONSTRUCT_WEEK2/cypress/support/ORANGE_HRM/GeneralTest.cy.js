class GeneralTest{
    GeneralTest(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index')
        cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').type("Admin")
        cy.get(':nth-child(3) > .oxd-input-group > :nth-child(2) > .oxd-input').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[1]').click()
        cy.xpath('(//span[@class="oxd-checkbox-input oxd-checkbox-input--active --label-right oxd-checkbox-input"])[1]').click()
    }

    clickOnFirstUsername(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index')
        cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').type("Admin")
        cy.get(':nth-child(3) > .oxd-input-group > :nth-child(2) > .oxd-input').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[1]').click()
        cy.xpath('(//span[@class="oxd-checkbox-input oxd-checkbox-input--active --label-right oxd-checkbox-input"])[2]').click()
    }

    clickOnSecondUsername(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index')
        cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').type("Admin")
        cy.get(':nth-child(3) > .oxd-input-group > :nth-child(2) > .oxd-input').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[1]').click()
        cy.xpath('(//span[@class="oxd-checkbox-input oxd-checkbox-input--active --label-right oxd-checkbox-input"])[3]').click()
    }

    clickOnThirdUsername(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index')
        cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').type("Admin")
        cy.get(':nth-child(3) > .oxd-input-group > :nth-child(2) > .oxd-input').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[1]').click()
        cy.xpath('(//span[@class="oxd-checkbox-input oxd-checkbox-input--active --label-right oxd-checkbox-input"])[4]').click()
    }

    typeOnEmployeeNameInPIM(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index')
        cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').type("Admin")
        cy.get(':nth-child(3) > .oxd-input-group > :nth-child(2) > .oxd-input').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[2]').click()
        cy.xpath('(//input[@placeholder="Type for hints..."])[1]').type("Sanket")
    }

    typeOnEmployeeIDInPIM(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index')
        cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').type("Admin")
        cy.get(':nth-child(3) > .oxd-input-group > :nth-child(2) > .oxd-input').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[2]').click()
        cy.xpath('(//input[@placeholder="Type for hints..."])[2]').type("ft38_566")
    }

    ClickOnSearchButtonInLeave(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index')
        cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').type("Admin")
        cy.get(':nth-child(3) > .oxd-input-group > :nth-child(2) > .oxd-input').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[3]').click()
        cy.xpath('//button[@class="oxd-button oxd-button--medium oxd-button--secondary orangehrm-left-space"]').click()
    }

    ClickOnResetButtonInLeave(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index')
        cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').type("Admin")
        cy.get(':nth-child(3) > .oxd-input-group > :nth-child(2) > .oxd-input').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[3]').click()
        cy.xpath('//button[@class="oxd-button oxd-button--medium oxd-button--ghost"]').click()
    }

    ClickOnViewButtonInTime(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index')
        cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').type("Admin")
        cy.get(':nth-child(3) > .oxd-input-group > :nth-child(2) > .oxd-input').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[4]').click()
        cy.xpath('//button[@class="oxd-button oxd-button--medium oxd-button--secondary orangehrm-left-space"]').click();
    }

    ClickOnViewButtonAndClickOnFirstViewButtonInTime(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index')
        cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').type("Admin")
        cy.get(':nth-child(3) > .oxd-input-group > :nth-child(2) > .oxd-input').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[4]').click()
        cy.xpath('(//button[@class="oxd-button oxd-button--medium oxd-button--text oxd-table-cell-action-space"])[1]').click();
    }

    MyInfoChangeName(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index')
        cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').type("Admin")
        cy.get(':nth-child(3) > .oxd-input-group > :nth-child(2) > .oxd-input').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[6]').click()
        cy.xpath('//input[@class="oxd-input oxd-input--active orangehrm-firstname"]').clear().type("Sanket")
    }

    MyInfoChangeMiddleName(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index')
        cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').type("Admin")
        cy.get(':nth-child(3) > .oxd-input-group > :nth-child(2) > .oxd-input').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[6]').click()
        cy.xpath('//input[@class="oxd-input oxd-input--active orangehrm-middlename"]').clear().type("Bharatrao")
    }

    MyInfoChangeLastName(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index')
        cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').type("Admin")
        cy.get(':nth-child(3) > .oxd-input-group > :nth-child(2) > .oxd-input').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[6]').click()
        cy.xpath('//input[@class="oxd-input oxd-input--active orangehrm-lastname"]').clear().type("Sarode")
    }

    MyInfoChangeEmployeeID(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index')
        cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').type("Admin")
        cy.get(':nth-child(3) > .oxd-input-group > :nth-child(2) > .oxd-input').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[6]').click()
        cy.xpath('(//input[@class="oxd-input oxd-input--active"])[2]').clear().type("ft38_566")
    }

    MyInfoChangeOtherID(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index')
        cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').type("Admin")
        cy.get(':nth-child(3) > .oxd-input-group > :nth-child(2) > .oxd-input').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[6]').click()
        cy.xpath('(//input[@class="oxd-input oxd-input--active"])[3]').clear().type("56688888")
    }

    MyInfoChangeDriversLicence(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index')
        cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').type("Admin")
        cy.get(':nth-child(3) > .oxd-input-group > :nth-child(2) > .oxd-input').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[6]').click()
        cy.xpath('(//input[@class="oxd-input oxd-input--active"])[4]').clear().type("788805")
    }

    MyInfoChangeTestField(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index')
        cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').type("Admin")
        cy.get(':nth-child(3) > .oxd-input-group > :nth-child(2) > .oxd-input').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[6]').click()
        cy.xpath('(//input[@class="oxd-input oxd-input--active"])[7]').clear().type("001")
    }


    // FAILED TEST CASES 2
    MyInfoSaveTheChange1(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index')
        cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').type("Admin")
        cy.get(':nth-child(3) > .oxd-input-group > :nth-child(2) > .oxd-input').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[6]').click()
        cy.xpath('(//input[@class="oxd-input oxd-input--active"])[2]').clear().type("ft38_566")
        cy.xpath('(//input[@class="oxd-input oxd-input--active"])[3]').clear().type("ft38_566")
        cy.xpath('(//input[@class="oxd-input oxd-input--active"])[4]').clear().type("ft38_566")
        cy.xpath('(//button[@type="submit"])[1]').click()
    }


    MyInfoSaveTheChange2(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index')
        cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').type("Admin")
        cy.get(':nth-child(3) > .oxd-input-group > :nth-child(2) > .oxd-input').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[6]').click()
        cy.xpath('(//input[@class="oxd-input oxd-input--active"])[7]').clear().type("001")
        cy.xpath('(//button[@class="oxd-button oxd-button--medium oxd-button--secondary orangehrm-left-space"])[2]').click()
    }

    TimeGet(){
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index')
        cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').type("Admin")
        cy.get(':nth-child(3) > .oxd-input-group > :nth-child(2) > .oxd-input').type("admin123")
        cy.xpath('//button[@type="submit"]').click()
        cy.xpath('(//a[@class="oxd-main-menu-item"])[4]').click()
    }

    

    





    
}

export default GeneralTest