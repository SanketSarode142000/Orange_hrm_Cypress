class TodaysNewsSubscribeCheck{
    TodaysNewsSubscribeCheck(){
        cy.visit('https://www.nytimes.com/');
        cy.xpath('//a[@href="https://www.nytimes.com/section/todayspaper"]').click({force: true});
        cy.xpath('(//a[@class="css-z6qatp"])[1]').should('be.visible')
    }

}

export default TodaysNewsSubscribeCheck