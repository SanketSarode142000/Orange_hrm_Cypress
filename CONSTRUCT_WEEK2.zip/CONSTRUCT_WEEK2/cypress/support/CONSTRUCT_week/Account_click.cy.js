class Account_click{
    account_click(){
        cy.visit('https://www.nytimes.com/');
        cy.xpath('//button[@aria-label="Account Information"]').should('have.text','Account');
    }
}

export default Account_click