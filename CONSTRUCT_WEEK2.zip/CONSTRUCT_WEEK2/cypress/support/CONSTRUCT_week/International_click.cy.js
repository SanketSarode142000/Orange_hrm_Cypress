class International_click{
    international_click(){
        cy.visit('https://www.nytimes.com/');
        cy.xpath('(//a[@class="css-1baq5tz"])[2]').click({force: true});
    //  cy.xpath('(//div[@class="a-section a-spacing-none"])[1]')
    }
}

export default International_click