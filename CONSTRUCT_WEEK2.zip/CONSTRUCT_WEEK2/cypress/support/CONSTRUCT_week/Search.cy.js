class Search{
    search(){
        cy.visit('https://www.nytimes.com/');
        cy.xpath('//a[@href="https://www.nytimes.com/section/todayspaper"]').click({force: true});

        cy.xpath('(//svg[@aria-hidden="true"])[3]').click()
    }
}

export default Search