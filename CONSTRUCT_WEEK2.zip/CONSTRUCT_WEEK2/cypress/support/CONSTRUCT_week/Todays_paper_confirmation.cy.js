class Todays_paper_confirmation{
    todays_paper_confirmation(){
        cy.visit('https://www.nytimes.com/');
        cy.xpath('//a[@href="https://www.nytimes.com/section/todayspaper"]').click({force: true});
        cy.xpath('//h1[@class="css-15bbg0b e16wpn5v0"]').should('have.text','Today’s Paper')
    }
}

export default Todays_paper_confirmation