class MiniCrossword_game{
    MiniCrossword_game(){
        cy.visit('https://www.nytimes.com/');
        // cy.xpath('//div[@class="css-xdandi"]').click({multiple : true})
        // cy.wait(10000)
        cy.xpath('(//button[@class="activeSearchButton css-tkwi90 e1iflr850"])').click()
        // cy.wait(10000)

    }
}


export default MiniCrossword_game