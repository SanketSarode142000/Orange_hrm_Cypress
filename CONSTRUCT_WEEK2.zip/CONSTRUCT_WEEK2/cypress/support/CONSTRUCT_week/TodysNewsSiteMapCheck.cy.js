class TodaysNewsSiteMapCheck{
    TodaysNewsSiteMapCheck(){
        cy.visit('https://www.nytimes.com/');
        // cy.xpath('//a[@href="https://www.nytimes.com/section/todayspaper"]').click({force: true});


        // cy.xpath('(//a[@data-testid="footer-link"])[11]').should('have.text', 'Site Map')


        
        // // click on video button
        //  cy.contains('Video').click({force: true})

        // cy.xpath('(//div[@class="css-xdandi"])[2]').click({force: true})

        // // click on Sweep Gives Trump and His Party a Governing Trifecta
        // cy.xpath('(//div[@class="css-xdandi"])[1]').should('have.text', 'Sweep Gives Trump and His Party a Governing Trifecta').click()

        
        cy.xpath('//a[@href="https://www.nytimes.com/section/todayspaper"]').click({force: true});
        cy.xpath('(//div[@class="css-141drxa"])[6]').should('contains.text','Free Electricity, Anyone? Britain Tries New Tricks to Green Its Grid.')


    }
}

export default TodaysNewsSiteMapCheck

