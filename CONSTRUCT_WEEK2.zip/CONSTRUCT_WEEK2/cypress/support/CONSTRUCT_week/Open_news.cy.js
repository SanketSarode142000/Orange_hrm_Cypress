class Open_news{
    open_news(){
        cy.visit('https://www.nytimes.com/');   // click on any news
        cy.xpath('(//div[@class="css-xdandi"])[1]').click();
    }
}

export default Open_news