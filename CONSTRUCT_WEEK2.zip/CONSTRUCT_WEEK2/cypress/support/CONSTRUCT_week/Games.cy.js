class Opinino{
    opinino(){
        cy.visit('https://www.nytimes.com/');
        cy.xpath('//div[@class="g-large-opinion-label"]').click({force: true});
    }
}

export default Opinino