class TodaysNewsFrontPageCheck{
    TodaysNewsFrontPageCheck(){
        cy.visit('https://www.nytimes.com/');
        cy.xpath('//a[@href="https://www.nytimes.com/section/todayspaper"]').click({force: true});
        cy.xpath('//h2[@class="css-q1brm6"]').should('have.text', ' The Front Page')
        // check whether we are on front page or not
    }
}

export default TodaysNewsFrontPageCheck