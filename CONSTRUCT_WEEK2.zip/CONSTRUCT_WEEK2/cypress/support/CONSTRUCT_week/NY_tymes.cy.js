class Home_Page{
    Home_page(){
        cy.visit('https://www.nytimes.com/');
    }
}

export default Home_Page