class Todays_paper{
    Todays_paper_info(){
        cy.visit('https://www.nytimes.com/');
        cy.xpath('//a[@href="https://www.nytimes.com/section/todayspaper"]').click({force: true});
        // cy.xpath('(//a[@class="css-1xphjhj"])[2]').click({force: true})
        // cy.xpath('(//h2[@class="css-1sd6y0f e1b0gigc0"])[1]').click({force: true})

    }
}

export default Todays_paper