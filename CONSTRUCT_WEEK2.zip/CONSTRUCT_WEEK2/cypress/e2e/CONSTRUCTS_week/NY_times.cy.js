import Home_Page from "../../support/CONSTRUCT_week/NY_tymes.cy";
import Todays_paper from "../../support/CONSTRUCT_week/Todays_paper.cy";
import Todays_paper_confirmation from "../../support/CONSTRUCT_week/Todays_paper_confirmation.cy";
import Account_click from "../../support/CONSTRUCT_week/Account_click.cy";
import Search from "../../support/CONSTRUCT_week/search.cy";
import International_click from "../../support/CONSTRUCT_week/International_click.cy";
import Open_news from "../../support/CONSTRUCT_week/Open_news.cy";
import Opinino from "../../support/CONSTRUCT_week/Games.cy";
import MiniCrossword_game from "../../support/CONSTRUCT_week/MiniCrossword_game.cy";
import TodaysNewsClick from "../../support/CONSTRUCT_week/TodaysNewsClick.cy";
import TodaysNewsFrontPageCheck from "../../support/CONSTRUCT_week/TodaysNewsFrontPageCheck.cy";
import Search2 from "../../support/CONSTRUCT_week/Search2.cy";
import TodaysNewsEditionWordCheck from "../../support/CONSTRUCT_week/TodaysNewsEditionWordCheck.cy";
import TodaysNewsEditionWordCheckNegative from "../../support/CONSTRUCT_week/TodaysNewsEditionWordCheckNegative.cy";
import TodaysNewsSubscribeCheck from "../../support/CONSTRUCT_week/TodaysNewsSubscribeCheck.cy";
import TodaysNewsSiteMapCheck from "../../support/CONSTRUCT_week/TodysNewsSiteMapCheck.cy";

describe('NY_times', () => {

    const Home_PageObj = new Home_Page;
    const Todays_paperObj = new Todays_paper;
    const Todays_paper_confirmationObj = new Todays_paper_confirmation;
    const Account_clickObj = new Account_click;
    const SearchObj = new Search;
    const International_clickObj = new International_click;
    const Open_newsObj = new Open_news;
    const OpininoObj = new Opinino;
    const MiniCrossword_gameObj = new MiniCrossword_game;
    const TodaysNewsClickObj = new TodaysNewsClick;
    const TodaysNewsFrontPageCheckObj = new TodaysNewsFrontPageCheck;
    const Search2Obj = new Search2;
    const TodaysNewsEditionWordCheckObj = new TodaysNewsEditionWordCheck;
    const TodaysNewsEditionWordCheckNegativeObj = new TodaysNewsEditionWordCheckNegative;
    const TodaysNewsSubscribeCheckObj = new TodaysNewsSubscribeCheck;
    const TodaysNewsSiteMapCheckObj = new TodaysNewsSiteMapCheck;

    it('Home_Page', () => {    // home page is available or not
        Home_PageObj.Home_page()
    });

    it('Todays_paper', () => {  // we can click it or not
        Todays_paperObj.Todays_paper_info()
    });

    it('Todays_paper_confirmation', () => {  // we really went to todays newspaper or not
        Todays_paper_confirmationObj.todays_paper_confirmation()
    });

   

    // it('Search', () => {
    //     SearchObj.search()
    // });

    it('International_click', () => {
        International_clickObj.international_click()
    });

    // it('Open_news', () => {
    //     Open_newsObj.open_news()
    // });

    it('Opinino', () => {
        OpininoObj.opinino()
    });

    // it('MiniCrossword_game', () => {
    //     MiniCrossword_gameObj.MiniCrossword_game()
    // });

    it('TodaysNewsClick', () => {
        TodaysNewsClickObj.TodaysNewsClick()
    });

    it('TodaysNewsFrontPageCheck', () => {
        TodaysNewsFrontPageCheckObj.TodaysNewsFrontPageCheck()
    });

    // it('Search2', () => {
    //     Search2Obj.Search2()
    // });

    it('TodaysNewsEditionWordCheck', () => {
        TodaysNewsEditionWordCheckObj.TodaysNewsEditionWordCheck()
    });

    it('TodaysNewsEditionWordCheckNegative', () => {
        TodaysNewsEditionWordCheckNegativeObj.TodaysNewsEditionWordCheckNegative()
    });

    // it('TodaysNewsSubscribeCheck', () => {
    //     TodaysNewsSubscribeCheckObj.TodaysNewsSubscribeCheck()
    // });

    it('TodaysNewsSiteMapCheck', () => {
        TodaysNewsSiteMapCheckObj.TodaysNewsSiteMapCheck()
    });

    it('', () => {
        
    });




});


